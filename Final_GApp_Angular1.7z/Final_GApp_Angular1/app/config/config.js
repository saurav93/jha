(function(){
	angular
	   .module("app")
	   .config(function($routeProvider){
	   	$routeProvider
		     	     .when("/",{
		     	     	controller:"logincontroller",
		     	     	templateUrl:"app/view/loginPage.html"
		     	     })
		     	     .when("/menu",{
		     	     	controller:"menucontroller",
		     	     	templateUrl:"app/view/menuPage.html"
		     	     })
		     	     .when("/currentevent/:id",{
		     	     	controller:"currentEventcontroller",
		     	     	templateUrl:"app/view/eventDetailsPage.html"
		     	     })
		     	     .when("/createevent",{
		     	     	controller:"createEventcontroller",
		     	     	templateUrl:"app/view/createEventPage.html"
		     	     })
		     	     
	   })
}())

