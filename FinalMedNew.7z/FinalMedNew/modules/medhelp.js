angular.module("medhelp", ["ngRoute"])
//.run(function($rootScope, $location) {
	// $rootScope.$on("$routeChangeStart", function(event, next, current) {
		// if (localStorage.un3 == null || localStorage.un3=="undefined" ) {
              // $location.path("/");
			// // already going to #signin, no redirect needed
		// } else {
//         
			// $location.path("/homepage");
//     
			// // not going to #signin, we should redirect now
// 			
// 			
		// }
	// });
//});
;
