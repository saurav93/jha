Admin ID:M1035897
Password:medhelp@kalinga
User ID: any other